# Load data.
Sigma_true <- read.csv("Sigma_true.csv", header = FALSE, sep = ",")   # True covariance matrix.
x_samples <- read.csv("x_samples.csv", header = FALSE, sep = ",")     # Samples from N(0, Sigma_true).
m <- nrow(x_samples)
n <- ncol(x_samples)
