using CSV

# Load training data.
Sigma_true = Matrix(CSV.read("Sigma_true.csv", datarow=1, delim=","));
x_samples = Matrix(CSV.read("x_samples.csv", datarow=1, delim=","));

m, n = size(x_samples)
