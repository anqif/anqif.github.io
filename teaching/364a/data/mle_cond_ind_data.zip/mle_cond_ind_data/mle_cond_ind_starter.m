% Load data.
Sigma_true = readmatrix("Sigma_true.csv");  % True covariance matrix.
x_samples = readmatrix("x_samples.csv");    % Samples from N(0, Sigma_true).
[m, n] = size(x_samples);
