import numpy as np

# Load data.
Sigma_true = np.loadtxt("Sigma_true.csv", delimiter = ",")   # True covariance matrix.
x_samples = np.loadtxt("x_samples.csv", delimiter = ",")     # Samples from N(0, Sigma_true).
m, n = x_samples.shape
