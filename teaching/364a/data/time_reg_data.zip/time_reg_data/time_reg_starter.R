# Load training data.
X_train <- read.csv("X_train.csv", header = FALSE, sep = ",")   # X[i,] is feature vector i.
t_train <- read.csv("t_train.csv", header = FALSE, sep = ",")   # t[i,1] is time stamp i.
y_train <- read.csv("y_train.csv", header = FALSE, sep = ",")   # y[i,1] is outcome i.

# Load test data.
X_test <- read.csv("X_test.csv", header = FALSE, sep = ",")
t_test <- read.csv("t_test.csv", header = FALSE, sep = ",")
y_test <- read.csv("y_test.csv", header = FALSE, sep = ",")

T_parm <- 20   # Time stamps vary from t = 1,...,T_parm.
m <- nrow(X_train)
n <- ncol(X_train)
M <- nrow(X_test)
