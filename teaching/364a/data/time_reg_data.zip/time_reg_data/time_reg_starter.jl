using CSV

# Load training data.
X_train = Matrix(CSV.read("X_train.csv", datarow=1, delim=","));
t_train = Matrix(CSV.read("t_train.csv", datarow=1, delim=","));
t_train = Int.(t_train)
y_train = Matrix(CSV.read("y_train.csv", datarow=1, delim=","));

# Load test data.
X_test = Matrix(CSV.read("X_test.csv", datarow=1, delim=","));
t_test = Matrix(CSV.read("t_test.csv", datarow=1, delim=","));
t_test = Int.(t_test)
y_test = Matrix(CSV.read("y_test.csv", datarow=1, delim=","));

T = 20   # Time stamps vary from t = 1,...,T.
m, n = size(X_train)
M, n = size(X_test)
