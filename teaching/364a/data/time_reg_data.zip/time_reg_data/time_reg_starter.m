% Load training data.
X_train = readmatrix("X_train.csv");  % X[i,:] is feature vector i.
t_train = readmatrix("t_train.csv");  % t[i] is time stamp i.
y_train = readmatrix("y_train.csv");  % y[i] is outcome i.

% Load test data.
X_test = readmatrix("X_test.csv");
t_test = readmatrix("t_test.csv");
y_test = readmatrix("y_test.csv");

T = 20;   % Time stamps vary from t = 1,...,T.
[m, n] = size(X_train);
[M, n] = size(X_test);
