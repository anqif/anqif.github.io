import numpy as np

# Load training data.
X_train = np.loadtxt("X_train.csv", delimiter = ",")                  # X[i,:] is feature vector i.
t_train = np.loadtxt("t_train.csv", delimiter = ",").astype(int)      # t[i] is time stamp i.
y_train = np.loadtxt("y_train.csv", delimiter = ",")                  # y[i] is outcome i.

# Load test data.
X_test = np.loadtxt("X_test.csv", delimiter = ",")
t_test = np.loadtxt("t_test.csv", delimiter = ",").astype(int)
y_test = np.loadtxt("y_test.csv", delimiter = ",")

# Python zero-indexing.
t_train = t_train - 1
t_test = t_test - 1

T = 20   # Time stamps vary from t = 1,...,T.
m, n = X_train.shape
M, n = X_test.shape
